#include "Client.h"




Client::Client(string n)
{
}

Client::~Client()
{
}
