#include "Bus.h"



Bus::Bus()
{
}


Bus::Bus(int cap)
{
}

Bus::~Bus()
{
}

bool Bus::isfull()
{
	return false;
}
