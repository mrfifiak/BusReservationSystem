#include "BusReservationSystem.h"



BusReservationSystem::BusReservationSystem()
{
}


BusReservationSystem::~BusReservationSystem()
{
}


// adds a new client
void BusReservationSystem::new_client()
{
}

//removes a client
void BusReservationSystem::remove_client()
{
}

// creates a bus
void BusReservationSystem::new_bus()
{
}

// removes a bus
void BusReservationSystem::remove_bus()
{
}

// creates a new trip
void BusReservationSystem::new_trip()
{
}

// removes a trip
void BusReservationSystem::remove_trip()
{
}

// changes client's data
void BusReservationSystem::change_client_data()
{
}

// choose a bus, then choose the trip
void BusReservationSystem::assign_bus_to_trip()
{
}

// choose a bus, then choose the trip
void BusReservationSystem::dismiss_bus_from_trip()
{
}

// choose a trip, then choose the bus
void BusReservationSystem::assign_trip_to_bus()
{
}

// choose a trip, then choose the bus
void BusReservationSystem::dismiss_trip_from_bus()
{
}

// changes trip's data
void BusReservationSystem::change_trip_data()
{
}

// prints all trips with buses and clients
void BusReservationSystem::print_trips()
{
}

// prints all trips' basic data
void BusReservationSystem::print_timetable()
{
}
