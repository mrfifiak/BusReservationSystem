#include "BusReservationSystem.h"
#include "Bus.h"
#include "Client.h"
#include "Trip.h"

using namespace std;

int main()
{

/*
#ifdef _WIN32
	system("Pause");
#endif
*/

	return 0;

}