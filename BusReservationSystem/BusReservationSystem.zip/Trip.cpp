#include "Trip.h"





Trip::Trip(string f, string t, int di, int depmo, int depda, int depho, int depmi, int durho, int durmi)
{
}

Trip::~Trip()
{
}
