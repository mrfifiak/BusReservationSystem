#include "Time.h"


/*	TO DELETE	*/
Time::Time()
{
}

// constructor with months=0, days=0, hours=ho, minutes=mi
Time::Time(int ho, int mi)
{
}

// constructor with months=mo, days=da, hours=ho, minutes=mi
Time::Time(int mo, int da, int ho, int mi)
{
}

//destructor
Time::~Time()
{
}

ostream & operator<<(ostream &o, Time const &t)
{
	return o;
}
